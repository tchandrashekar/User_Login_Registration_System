package com.example.User_Login_System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserLoginSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
